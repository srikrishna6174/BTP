"""
Authentication Server (AS) — Listens for connections from AP.
Full authentication protocol with timing, energy, and communication metrics.
"""

import socket
import json
import base64
import hashlib
import os
import sys
import time
import resource
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

HOST = ''
PORT = int(os.environ.get('AS_PORT', '55556'))

# Typical server power draw in watts
AS_POWER_WATTS = float(os.environ.get('AS_POWER_WATTS', '65.0'))

# --- METRICS COLLECTOR ---
class Metrics:
    def __init__(self):
        self.phases = []
        self.total_bytes_sent = 0
        self.total_bytes_recv = 0
        self._phase_start_wall = None
        self._phase_start_cpu = None
        self._phase_bytes_sent = 0
        self._phase_bytes_recv = 0
        self._total_start_wall = None
        self._total_start_cpu = None

    def start_total(self):
        self._total_start_wall = time.perf_counter()
        self._total_start_cpu = time.process_time()

    def start_phase(self, name):
        self._phase_start_wall = time.perf_counter()
        self._phase_start_cpu = time.process_time()
        self._phase_bytes_sent = 0
        self._phase_bytes_recv = 0
        self._current_phase = name

    def record_send(self, nbytes):
        self._phase_bytes_sent += nbytes
        self.total_bytes_sent += nbytes

    def record_recv(self, nbytes):
        self._phase_bytes_recv += nbytes
        self.total_bytes_recv += nbytes

    def end_phase(self):
        wall = time.perf_counter() - self._phase_start_wall
        cpu = time.process_time() - self._phase_start_cpu
        energy = cpu * AS_POWER_WATTS
        self.phases.append({
            'name': self._current_phase,
            'wall_time_ms': wall * 1000,
            'cpu_time_ms': cpu * 1000,
            'energy_mJ': energy * 1000,
            'bytes_sent': self._phase_bytes_sent,
            'bytes_recv': self._phase_bytes_recv,
        })

    def print_summary(self):
        total_wall = time.perf_counter() - self._total_start_wall
        total_cpu = time.process_time() - self._total_start_cpu
        total_energy = total_cpu * AS_POWER_WATTS

        ru = resource.getrusage(resource.RUSAGE_SELF)

        print("\n" + "=" * 70)
        print("   AUTHENTICATION SERVER (AS) — PERFORMANCE METRICS")
        print("=" * 70)
        print(f"  Power Model: {AS_POWER_WATTS} W (set AS_POWER_WATTS to change)")
        print("-" * 70)
        print(f"  {'Phase':<30} {'Wall(ms)':>10} {'CPU(ms)':>10} "
              f"{'Energy(mJ)':>12} {'Sent(B)':>9} {'Recv(B)':>9}")
        print("-" * 70)

        for p in self.phases:
            print(f"  {p['name']:<30} {p['wall_time_ms']:>10.3f} "
                  f"{p['cpu_time_ms']:>10.3f} {p['energy_mJ']:>12.4f} "
                  f"{p['bytes_sent']:>9d} {p['bytes_recv']:>9d}")

        print("-" * 70)
        print(f"  {'TOTAL':<30} {total_wall*1000:>10.3f} "
              f"{total_cpu*1000:>10.3f} {total_energy*1000:>12.4f} "
              f"{self.total_bytes_sent:>9d} {self.total_bytes_recv:>9d}")
        print("=" * 70)
        print(f"  Total Wall-Clock Time : {total_wall*1000:.3f} ms")
        print(f"  Total CPU Time        : {total_cpu*1000:.3f} ms")
        print(f"  Total Energy (est.)   : {total_energy*1000:.4f} mJ "
              f"({total_energy*1e6:.2f} µJ)")
        print(f"  Total Bytes Sent      : {self.total_bytes_sent} bytes")
        print(f"  Total Bytes Received  : {self.total_bytes_recv} bytes")
        print(f"  Total Communication   : {self.total_bytes_sent + self.total_bytes_recv} bytes")
        print("-" * 70)
        print(f"  Max RSS Memory        : {ru.ru_maxrss} KB")
        print(f"  User CPU Time (OS)    : {ru.ru_utime*1000:.3f} ms")
        print(f"  System CPU Time (OS)  : {ru.ru_stime*1000:.3f} ms")
        print("=" * 70)

metrics = Metrics()

# --- CRYPTO HELPERS ---
def sha256(*args):
    h = hashlib.sha256()
    for a in args: h.update(a)
    return h.digest()

def xor_bytes(b1, b2):
    return bytes(x ^ y for x, y in zip(b1, b2))

def pad_16(b):
    return b.ljust(32, b'\x00')

def aes_encrypt(key, data):
    iv = os.urandom(16)
    pad_len = 16 - (len(data) % 16)
    data += bytes([pad_len]) * pad_len
    cipher = Cipher(algorithms.AES(key[:32]), modes.CBC(iv))
    enc = cipher.encryptor()
    ct = enc.update(data) + enc.finalize()
    return iv + ct

def aes_decrypt(key, enc_data):
    iv, ct = enc_data[:16], enc_data[16:]
    cipher = Cipher(algorithms.AES(key[:32]), modes.CBC(iv))
    dec = cipher.decryptor()
    pt = dec.update(ct) + dec.finalize()
    return pt[:-pt[-1]]

# --- NETWORK HELPERS (instrumented) ---
def send_msg(sock, data):
    msg = json.dumps(data).encode('utf-8')
    raw = len(msg).to_bytes(4, 'big') + msg
    sock.sendall(raw)
    metrics.record_send(len(raw))

def recv_msg(sock):
    raw = recvall(sock, 4)
    if not raw: return None
    msglen = int.from_bytes(raw, 'big')
    data = recvall(sock, msglen)
    if not data: return None
    metrics.record_recv(4 + msglen)
    return json.loads(data.decode('utf-8'))

def recvall(sock, n):
    data = bytearray()
    while len(data) < n:
        pkt = sock.recv(n - len(data))
        if not pkt: return None
        data.extend(pkt)
    return data

# --- PROTOCOL ---
class ASProtocol:
    def __init__(self):
        self.sidi = os.urandom(16)
        self.sks = ec.generate_private_key(ec.SECP256R1())
        self.pks = self.sks.public_key()
        self.aps = os.urandom(32)
        self.db = {}

    def execute_handshake(self, conn):
        metrics.start_total()

        pks_pem = self.pks.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode('utf-8')

        # === PRE-REGISTRATION ===
        metrics.start_phase("Pre-Registration")
        print("\n[AS] --- PRE-REGISTRATION PHASE ---")
        psw = os.urandom(16)
        send_msg(conn, {'psw': base64.b64encode(psw).decode('utf-8'), 'pks': pks_pem})
        print("[AS] Sent PSW and PKS to IoT (via AP).")
        metrics.end_phase()

        # === ALGORITHM 2 — Server Registration Processing ===
        metrics.start_phase("Algo 2 — Reg Processing")
        print("\n[AS] --- REGISTRATION PHASE (Algorithm 2) ---")
        reg_req = recv_msg(conn)
        if not reg_req:
            print("[AS] ERROR: No registration request received.")
            return None
        e1 = base64.b64decode(reg_req['E1'])
        h1 = base64.b64decode(reg_req['H1'])
        eph_pub_bytes = base64.b64decode(reg_req['eph_pub'])

        eph_pub = serialization.load_pem_public_key(eph_pub_bytes)
        shared_secret = self.sks.exchange(ec.ECDH(), eph_pub)
        aes_key_e1 = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'handshake').derive(shared_secret)

        decrypted_e1 = aes_decrypt(aes_key_e1, e1)

        i_i = decrypted_e1[:32]
        n_a = decrypted_e1[32:48]
        t_1 = decrypted_e1[48:56]
        et = decrypted_e1[56:64]
        lia_i = decrypted_e1[64:80]
        tid_i = decrypted_e1[80:96]
        w = decrypted_e1[96:112]
        p_list_mock = decrypted_e1[112:128]

        h1_check = sha256(i_i, n_a, t_1, et, lia_i, tid_i, w, p_list_mock)
        if h1_check != h1:
            print("[AS] ERROR: Integrity check failed on E1.")
            return None

        msk = sha256(n_a, self.sks.private_numbers().private_value.to_bytes(32, 'big'), i_i)
        r1 = os.urandom(16)
        midi = aes_encrypt(msk, i_i + r1)
        msidi = aes_encrypt(msk, self.sidi + r1)

        n_b = os.urandom(16)
        k_reg = sha256(pad_16(n_a), pad_16(n_b), i_i)

        ot_list = [os.urandom(16) for _ in range(10)]
        ot_list_bytes = b''.join(ot_list)
        ot_enc = aes_encrypt(k_reg, ot_list_bytes)
        msk_enc = aes_encrypt(k_reg, msk)

        t_3 = str(123456).encode('utf-8').ljust(8, b'\x00')
        e2_key = sha256(xor_bytes(pad_16(n_a), i_i))
        e2_payload = midi + msidi + n_b + t_3 + msk_enc + ot_enc
        e2 = aes_encrypt(e2_key, e2_payload)
        h2 = sha256(midi, msidi, n_b, t_3, msk_enc, ot_enc)

        self.db[midi] = {
            'i_i': i_i, 'msk': msk, 'r1': r1,
            'k_reg': k_reg, 'ot_list': ot_list, 'msidi': msidi
        }

        send_msg(conn, {
            'E2': base64.b64encode(e2).decode('utf-8'),
            'H2': base64.b64encode(h2).decode('utf-8')
        })
        print("[AS] Registration successful. Sent E2, H2 to IoT (via AP).")
        metrics.end_phase()

        # === ALGORITHM 5 — Device Authentication by Server ===
        metrics.start_phase("Algo 5 — Device Auth")
        print("\n[AS] --- AUTHENTICATION PHASE (Algorithm 5) ---")
        auth_req = recv_msg(conn)
        if not auth_req:
            print("[AS] ERROR: No auth request received.")
            return None
        midi_recv = base64.b64decode(auth_req['Midi'])
        m1 = base64.b64decode(auth_req['M1'])
        ha1 = base64.b64decode(auth_req['HA1'])

        if midi_recv not in self.db:
            print("[AS] ERROR: Unknown device.")
            return None

        record = self.db[midi_recv]
        k_reg_db = record['k_reg']
        decrypted_m1 = aes_decrypt(k_reg_db, m1)

        i_u = decrypted_m1[:32]
        msidi_recv = decrypted_m1[32:96]
        n_c = decrypted_m1[96:112]
        t_1_auth = decrypted_m1[112:120]
        r_1_auth = decrypted_m1[120:136]
        lia_i_recv = decrypted_m1[136:152]
        ot_idx = int.from_bytes(decrypted_m1[152:156], 'big')

        ha1_check = sha256(i_u, msidi_recv, n_c, t_1_auth, r_1_auth, lia_i_recv, ot_idx.to_bytes(4, 'big'))
        if ha1_check != ha1:
            print("[AS] ERROR: Auth integrity check failed.")
            return None

        print("[AS] Device authenticated by Server.")

        ot_j = record['ot_list'][ot_idx]
        r_2 = os.urandom(16)
        n_d = os.urandom(16)

        k_new = sha256(k_reg_db, ot_j, n_c, r_1_auth)
        i_u_n = sha256(xor_bytes(xor_bytes(record['i_i'], pad_16(r_1_auth)), pad_16(r_2)))
        sk = sha256(k_new, n_d, i_u_n)

        midi_new = aes_encrypt(record['msk'], record['i_i'] + r_2)
        msidi_new = aes_encrypt(record['msk'], self.sidi + r_2)

        tsk = os.urandom(16)
        et_fr = b"EXP_TIME"
        mtid_t = aes_encrypt(self.aps, midi_new)

        t_3_auth = str(123457).encode('utf-8').ljust(8, b'\x00')
        m2_payload = i_u_n + midi_new + msidi_new + n_d + t_3_auth + r_2 + tsk + et_fr + mtid_t
        m2 = aes_encrypt(k_new, m2_payload)
        ha2 = sha256(i_u_n, midi_new, msidi_new, n_d, t_3_auth, r_2, tsk, et_fr, mtid_t)

        send_msg(conn, {
            'M2': base64.b64encode(m2).decode('utf-8'),
            'HA2': base64.b64encode(ha2).decode('utf-8')
        })
        print("[AS] Sent M2, HA2. Handshake COMPLETE!")
        print(f"[AS] Session Key: {sk.hex()}")
        metrics.end_phase()

        return sk


def main():
    print("=" * 55)
    print("       AUTHENTICATION SERVER (AS) — Docker")
    print("=" * 55)
    print(f"  Listening on port {PORT}")
    print("=" * 55)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)

    print(f"\n[AS] Waiting for connections on port {PORT} ...")

    auth = ASProtocol()

    while True:
        conn, addr = server.accept()
        print(f"\n[AS] Connection from {addr[0]}:{addr[1]} (via AP)")

        try:
            sk = auth.execute_handshake(conn)
        except Exception as e:
            print(f"[AS] Handshake error (possibly a probe): {e}")
            conn.close()
            continue

        if not sk:
            print("[AS] Protocol FAILED.")
            conn.close()
            continue

        # Receive test message
        metrics.start_phase("Secure Message Exchange")
        try:
            enc_data = conn.recv(4096)
            if enc_data:
                metrics.record_recv(len(enc_data))
                msg = aes_decrypt(sk, enc_data)
                print(f"[AS] Received from IoT: {msg.decode('utf-8')}")

                # Send response
                resp = b"Hello from AS! Secure session confirmed."
                enc_resp = aes_encrypt(sk, resp)
                conn.sendall(enc_resp)
                metrics.record_send(len(enc_resp))
                print("[AS] Sent encrypted response to IoT.")
        except Exception as e:
            print(f"[AS] Error: {e}")
        metrics.end_phase()

        print("\n[AS] Protocol demonstration complete.")
        metrics.print_summary()
        conn.close()


if __name__ == '__main__':
    main()
