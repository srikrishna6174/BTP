"""
Access Point (AP) — Transparent TCP Relay
Bridges IoT and AS without inspecting or modifying any messages.
"""

import socket
import threading
import os
import time

IOT_LISTEN_PORT = 55555
AS_HOST = os.environ.get('AS_HOST', 'as_server')
AS_PORT = int(os.environ.get('AS_PORT', '55556'))


def relay(src, dst, label):
    """Forward all bytes from src to dst."""
    try:
        while True:
            data = src.recv(4096)
            if not data:
                print(f"[AP] {label}: closed.")
                break
            dst.sendall(data)
    except (ConnectionResetError, BrokenPipeError, OSError) as e:
        print(f"[AP] {label}: ended — {e}")
    finally:
        try: src.close()
        except OSError: pass
        try: dst.close()
        except OSError: pass


def wait_for_as():
    """Wait for AS by resolving its hostname (no TCP connect to avoid
    the probe being consumed by AS's accept loop)."""
    print(f"[AP] Waiting for AS at {AS_HOST}:{AS_PORT} ...")
    while True:
        try:
            socket.getaddrinfo(AS_HOST, AS_PORT)
            print("[AP] AS hostname resolved. Ready.")
            return
        except socket.gaierror:
            time.sleep(1)


def connect_to_as():
    """Connect to AS with retries."""
    for attempt in range(10):
        try:
            as_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            as_sock.connect((AS_HOST, AS_PORT))
            return as_sock
        except (ConnectionRefusedError, OSError):
            print(f"[AP] AS not ready, retry {attempt+1}/10 ...")
            time.sleep(2)
    return None


def main():
    wait_for_as()
    # Give AS a moment to start listening
    time.sleep(2)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('', IOT_LISTEN_PORT))
    server.listen(5)
    print(f"[AP] Listening for IoT on port {IOT_LISTEN_PORT} ...")

    while True:
        iot_conn, iot_addr = server.accept()
        print(f"[AP] IoT connected from {iot_addr[0]}:{iot_addr[1]}")

        as_sock = connect_to_as()
        if not as_sock:
            print("[AP] Cannot reach AS after retries.")
            iot_conn.close()
            continue
        print(f"[AP] Connected to AS at {AS_HOST}:{AS_PORT}")

        t1 = threading.Thread(target=relay, args=(iot_conn, as_sock, "IoT→AS"), daemon=True)
        t2 = threading.Thread(target=relay, args=(as_sock, iot_conn, "AS→IoT"), daemon=True)
        t1.start()
        t2.start()
        print(f"[AP] Relaying traffic for {iot_addr[0]}:{iot_addr[1]}")


if __name__ == '__main__':
    main()
